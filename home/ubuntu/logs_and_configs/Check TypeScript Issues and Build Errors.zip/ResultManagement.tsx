import React, { useState, useEffect } from 'react';
import { Card, Table, Button, Input, Select, Spin, message, Modal, Form, Tabs, Tag, Checkbox } from 'antd'; // FIX: Import Checkbox
import { PlusOutlined, SearchOutlined, CheckOutlined, CloseOutlined, EditOutlined } from '@ant-design/icons';
import dayjs from 'dayjs'; // FIX: Use dayjs instead of moment
import type { Dayjs } from 'dayjs';

const { Option } = Select;
const { TabPane } = Tabs;

// Define interfaces for data types
interface LabResult {
  id: string;
  order_item_id: string;
  test_name: string;
  parameter_id?: string;
  parameter_name?: string;
  result_value: string;
  unit?: string;
  reference_range_male?: string;
  reference_range_female?: string;
  is_abnormal: boolean;
  notes?: string;
  performed_by?: string;
  performed_by_name?: string;
  performed_at?: string;
  verified_by?: string;
  verified_by_name?: string;
  verified_at?: string;
}

interface LabOrder {
  id: string;
  patient_name: string;
  // Add other relevant order fields if needed for display
}

interface LabOrderItem {
  id: string;
  test_id: string;
  test_name: string;
  // Add other relevant item fields if needed
}

interface LabParameter {
  id: string;
  name: string;
  unit?: string;
  // Add other relevant parameter fields if needed
}

// FIX: Define API response types
interface ResultsApiResponse {
  results?: LabResult[];
}

interface OrdersApiResponse {
  results?: LabOrder[];
}

interface OrderItemsApiResponse {
  results?: LabOrderItem[];
}

interface ParametersApiResponse {
  results?: LabParameter[];
}

interface ApiErrorResponse {
  error?: string;
}

interface UpdateResultValues {
  result_value: string;
  is_abnormal: boolean;
  notes?: string;
}

interface CreateResultValues {
  parameter_id?: string;
  result_value: string;
  is_abnormal: boolean;
  notes?: string;
}

const ResultManagement: React.FC = () => {
  const [results, setResults] = useState<LabResult[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [searchText, setSearchText] = useState<string>('');
  const [orderFilter, setOrderFilter] = useState<string | null>(null);
  const [isModalVisible, setIsModalVisible] = useState<boolean>(false);
  const [isEntryModalVisible, setIsEntryModalVisible] = useState<boolean>(false);
  const [selectedResult, setSelectedResult] = useState<LabResult | null>(null);
  const [selectedOrderItem, setSelectedOrderItem] = useState<LabOrderItem | null>(null);
  const [form] = Form.useForm<UpdateResultValues>();
  const [entryForm] = Form.useForm<CreateResultValues>();
  const [orders, setOrders] = useState<LabOrder[]>([]); // For order selection
  const [orderItems, setOrderItems] = useState<LabOrderItem[]>([]); // For result entry
  const [parameters, setParameters] = useState<LabParameter[]>([]); // For parameter selection

  // Fetch results with optional filters
  const fetchResults = React.useCallback(async (): Promise<void> => { // Wrapped in useCallback
    setLoading(true);
    try {
      let url = '/api/laboratory/results';
      const params = new URLSearchParams();

      if (orderFilter) {
        params.append('orderId', orderFilter);
      }

      if (params.toString()) {
        url += `?${params.toString()}`;
      }

      const response = await fetch(url);
      if (!response.ok) {
        let errorMsg = 'Failed to fetch results';
        try {
          const errorData: ApiErrorResponse = await response.json();
          errorMsg = errorData.error || errorMsg;
        } catch (jsonError) { /* Ignore */ }
        throw new Error(errorMsg);
      }
      // FIX: Type the response data
      const data: ResultsApiResponse = await response.json();

      let fetchedResults: LabResult[] = data.results || [];

      // Filter by search text if provided
      if (searchText) {
        const searchLower = searchText.toLowerCase();
        fetchedResults = fetchedResults.filter(result =>
          result.test_name?.toLowerCase().includes(searchLower) ||
          result.parameter_name?.toLowerCase().includes(searchLower) ||
          result.result_value?.toLowerCase().includes(searchLower)
        );
      }

      setResults(fetchedResults);
    } catch (err: unknown) { // FIX: Use unknown
      const messageText = err instanceof Error ? err.message : 'An unknown error occurred';
      console.error('Error fetching results:', err);
      message.error(`Failed to load laboratory results: ${messageText}`);
    } finally {
      setLoading(false);
    }
  }, [orderFilter, searchText]); // Added dependencies

  // Fetch orders for filter dropdown
  const fetchOrders = async (): Promise<void> => {
    try {
      const response = await fetch('/api/laboratory/orders');
      if (!response.ok) {
        let errorMsg = 'Failed to fetch orders';
        try {
          const errorData: ApiErrorResponse = await response.json();
          errorMsg = errorData.error || errorMsg;
        } catch (jsonError) { /* Ignore */ }
        throw new Error(errorMsg);
      }
      // FIX: Type the response data
      const data: OrdersApiResponse = await response.json();
      setOrders(data.results || []);
    } catch (err: unknown) { // FIX: Use unknown
      const messageText = err instanceof Error ? err.message : 'An unknown error occurred';
      console.error('Error fetching orders:', err);
      message.error(`Failed to load laboratory orders: ${messageText}`);
    }
  };

  // Fetch order items for a specific order
  const fetchOrderItems = async (orderId: string): Promise<void> => {
    try {
      const response = await fetch(`/api/laboratory/orders/${orderId}/items`);
      if (!response.ok) {
        let errorMsg = 'Failed to fetch order items';
        try {
          const errorData: ApiErrorResponse = await response.json();
          errorMsg = errorData.error || errorMsg;
        } catch (jsonError) { /* Ignore */ }
        throw new Error(errorMsg);
      }
      // FIX: Type the response data
      const data: OrderItemsApiResponse = await response.json();
      setOrderItems(data.results || []);
    } catch (err: unknown) { // FIX: Use unknown
      const messageText = err instanceof Error ? err.message : 'An unknown error occurred';
      console.error('Error fetching order items:', err);
      message.error(`Failed to load order items: ${messageText}`);
    }
  };

  // Fetch parameters for a specific test
  const fetchParameters = async (testId: string): Promise<void> => {
    try {
      const response = await fetch(`/api/laboratory/tests/${testId}/parameters`);
      if (!response.ok) {
        let errorMsg = 'Failed to fetch test parameters';
        try {
          const errorData: ApiErrorResponse = await response.json();
          errorMsg = errorData.error || errorMsg;
        } catch (jsonError) { /* Ignore */ }
        throw new Error(errorMsg);
      }
      // FIX: Type the response data
      const data: ParametersApiResponse = await response.json();
      setParameters(data.results || []);
    } catch (err: unknown) { // FIX: Use unknown
      const messageText = err instanceof Error ? err.message : 'An unknown error occurred';
      console.error('Error fetching test parameters:', err);
      message.error(`Failed to load test parameters: ${messageText}`);
    }
  };

  // Load data on component mount
  useEffect(() => {
    fetchResults();
    fetchOrders();
  }, [fetchResults]); // Added fetchResults dependency

  // Reload results when filters change
  useEffect(() => {
    fetchResults();
  }, [orderFilter, searchText, fetchResults]); // Added fetchResults dependency

  // Handle updating a result
  const handleUpdateResult = async (values: UpdateResultValues): Promise<void> => {
    if (!selectedResult) return;
    try {
      const response = await fetch('/api/laboratory/results', {
        method: 'POST', // Assuming POST handles updates via ID
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          id: selectedResult.id,
          ...values
        }),
      });

      if (!response.ok) {
        // FIX: Type the error response
        let errorMsg = 'Failed to update result';
        try {
          const errorData: ApiErrorResponse = await response.json();
          errorMsg = errorData.error || errorMsg;
        } catch (jsonError) { /* Ignore */ }
        throw new Error(errorMsg);
      }

      message.success('Result updated successfully');
      setIsModalVisible(false);
      form.resetFields();
      fetchResults();
    } catch (err: unknown) { // FIX: Use unknown
      const messageText = err instanceof Error ? err.message : 'An unknown error occurred';
      console.error('Error updating result:', err);
      message.error(messageText);
    }
  };

  // Handle creating a new result
  const handleCreateResult = async (values: CreateResultValues): Promise<void> => {
    if (!selectedOrderItem) return;
    try {
      const response = await fetch('/api/laboratory/results', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          order_item_id: selectedOrderItem.id,
          ...values
        }),
      });

      if (!response.ok) {
        // FIX: Type the error response
        let errorMsg = 'Failed to create result';
        try {
          const errorData: ApiErrorResponse = await response.json();
          errorMsg = errorData.error || errorMsg;
        } catch (jsonError) { /* Ignore */ }
        throw new Error(errorMsg);
      }

      message.success('Result created successfully');
      setIsEntryModalVisible(false);
      entryForm.resetFields();
      fetchResults();
    } catch (err: unknown) { // FIX: Use unknown
      const messageText = err instanceof Error ? err.message : 'An unknown error occurred';
      console.error('Error creating result:', err);
      message.error(messageText);
    }
  };

  // Handle verifying a result
  const handleVerifyResult = async (result: LabResult): Promise<void> => {
    try {
      const response = await fetch('/api/laboratory/results', {
        method: 'POST', // Assuming POST handles verification
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          id: result.id,
          verify: true
        }),
      });

      if (!response.ok) {
        // FIX: Type the error response
        let errorMsg = 'Failed to verify result';
        try {
          const errorData: ApiErrorResponse = await response.json();
          errorMsg = errorData.error || errorMsg;
        } catch (jsonError) { /* Ignore */ }
        throw new Error(errorMsg);
      }

      message.success('Result verified successfully');
      fetchResults();
    } catch (err: unknown) { // FIX: Use unknown
      const messageText = err instanceof Error ? err.message : 'An unknown error occurred';
      console.error('Error verifying result:', err);
      message.error(messageText);
    }
  };

  // Show result entry modal
  const showResultEntryModal = (orderItem: LabOrderItem): void => {
    setSelectedOrderItem(orderItem);
    entryForm.resetFields();
    setParameters([]); // Reset parameters

    // If the test has parameters, fetch them
    if (orderItem.test_id) {
      fetchParameters(orderItem.test_id);
    }

    setIsEntryModalVisible(true);
  };

  // Show result update modal
  const showResultUpdateModal = (result: LabResult): void => {
    setSelectedResult(result);
    form.setFieldsValue({
      result_value: result.result_value,
      is_abnormal: result.is_abnormal,
      notes: result.notes || ''
    });
    setIsModalVisible(true);
  };

  // Table columns
  const columns = [
    {
      title: 'Test',
      dataIndex: 'test_name',
      key: 'test_name',
      width: '15%',
    },
    {
      title: 'Parameter',
      dataIndex: 'parameter_name',
      key: 'parameter_name',
      width: '15%',
      render: (name: string | undefined) => name || 'N/A',
    },
    {
      title: 'Result',
      dataIndex: 'result_value',
      key: 'result_value',
      width: '15%',
    },
    {
      title: 'Unit',
      dataIndex: 'unit',
      key: 'unit',
      width: '10%',
      render: (unit: string | undefined) => unit || 'N/A',
    },
    {
      title: 'Reference Range',
      key: 'reference_range',
      width: '15%',
      render: (_: any, record: LabResult) => {
        // Simplified - in a real app, you'd use patient gender/age to determine which range to show
        return record.reference_range_male || record.reference_range_female || 'N/A';
      },
    },
    {
      title: 'Status',
      key: 'status',
      width: '10%',
      render: (_: any, record: LabResult) => {
        if (record.verified_by) {
          return <Tag color="success">Verified</Tag>;
        } else if (record.is_abnormal) {
          return <Tag color="error">Abnormal</Tag>;
        } else {
          return <Tag color="processing">Pending</Tag>;
        }
      },
    },
    {
      title: 'Performed By',
      dataIndex: 'performed_by_name',
      key: 'performed_by_name',
      width: '15%',
      render: (name: string | undefined) => name || 'N/A',
    },
    {
      title: 'Actions',
      key: 'actions',
      width: '15%',
      render: (_: any, record: LabResult) => {
        const actions = [];

        // Edit action (only if not verified)
        if (!record.verified_by) {
          actions.push(
            <Button
              key="edit"
              type="link"
              icon={<EditOutlined />}
              onClick={() => showResultUpdateModal(record)}
            >
              Edit
            </Button>
          );
        }

        // Verify action (only if not verified and user has permission - permission check omitted for brevity)
        if (!record.verified_by) {
          actions.push(
            <Button
              key="verify"
              type="link"
              icon={<CheckOutlined />}
              onClick={() => handleVerifyResult(record)}
            >
              Verify
            </Button>
          );
        }

        return actions.length > 0 ? <>{actions}</> : 'N/A';
      },
    },
  ];

  return (
    <div className="result-management-container">
      <Card
        title="Laboratory Result Management"
        extra={
          <Button
            type="primary"
            icon={<PlusOutlined />}
            onClick={() => {
              // TODO: Implement proper order/item selection for result entry
              message.info('Select an order/item to enter results for (feature pending).');
            }}
          >
            Enter Results
          </Button>
        }
      >
        <div className="filter-container" style={{ marginBottom: 16, display: 'flex', flexWrap: 'wrap', gap: 16 }}>
          <Input
            placeholder="Search results..."
            prefix={<SearchOutlined />}
            value={searchText}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchText(e.target.value)}
            // onPressEnter={fetchResults} // fetchResults is called via useEffect
            style={{ width: 250 }}
          />

          <Select
            placeholder="Filter by Order"
            allowClear
            showSearch
            optionFilterProp="children"
            style={{ width: 250 }}
            value={orderFilter}
            onChange={(value: string | null) => setOrderFilter(value)}
            filterOption={(input, option) =>
              (option?.children as unknown as string)?.toLowerCase().includes(input.toLowerCase()) ?? false
            }
          >
            {orders.map(order => (
              <Option key={order.id} value={order.id}>
                Order #{order.id} - {order.patient_name}
              </Option>
            ))}
          </Select>

          <Button
            onClick={() => {
              setSearchText('');
              setOrderF
(Content truncated due to size limit. Use line ranges to read in chunks)